def translate(code, lang):
    return f"[GERHARDT-LINEAGE::{lang}]=>{{{code}}}"
