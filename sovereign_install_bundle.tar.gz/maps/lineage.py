def translate(code, lang):
    # Novel: uses symbolic recursion with historical tool inheritance
    return f"[GERHARDT-LINEAGE::{lang}]=>{{{code}}}"
