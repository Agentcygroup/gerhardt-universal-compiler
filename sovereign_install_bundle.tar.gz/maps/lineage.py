def translate(code, lang):
    return f"IntermediateRep({lang}):{code}"
